This is the actual README file.
yes i know this is stupid.
but there is no code crap here.
extra commands is highly appreciated.
Thanks for Downloading Have fun :)
